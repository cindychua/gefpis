require 'test_helper'

class TuteeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
