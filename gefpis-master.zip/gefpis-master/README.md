# gefpis

5-5-16
Hi! This is what we have so far:
- [x] controllers
- [x] models
- [x] associations
- [ ] show
- [ ] create/update
- [ ] delete
- [ ] devise
- [ ] embedded pdf reader/module uploads

