class PagesController < ApplicationController
  def index
    render "pages/login"
  end

  def about
  end

  def login
  end
end
