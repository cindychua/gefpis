class PagesController < ApplicationController
  def index
    render "pages/login"
  end

  def about
  end
end
